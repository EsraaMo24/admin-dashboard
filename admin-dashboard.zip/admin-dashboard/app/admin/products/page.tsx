import { AdminLayout } from "@/components/admin-layout"

export default function AdminProductsPage() {
  return (
    <AdminLayout>
      <AdminProductsContent />
    </AdminLayout>
  )
}
// Separate the content component
;("use client")
import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddProductForm } from "@/components/add-product-form"
import { ProductTable } from "@/components/product-table"

function AdminProductsContent() {
  const [isAddProductOpen, setIsAddProductOpen] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Products</h1>
        <Button onClick={() => setIsAddProductOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Product
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <ProductTable />
        </CardContent>
      </Card>

      {/* Add Product Modal */}
      <AddProductForm isOpen={isAddProductOpen} onClose={() => setIsAddProductOpen(false)} />
    </div>
  )
}
