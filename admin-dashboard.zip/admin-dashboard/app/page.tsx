import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="max-w-md w-full p-6 bg-white rounded-lg shadow-md">
        <h1 className="text-2xl font-bold text-center mb-6">Store Management System</h1>
        <div className="space-y-4">
          <Link href="/login" className="w-full">
            <Button className="w-full">Login</Button>
          </Link>
          <Link href="/admin" className="w-full">
            <Button variant="outline" className="w-full">
              Go to Admin Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
