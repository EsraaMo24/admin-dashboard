
import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useToast } from "@/components/ui/use-toast"

type StoreSettings = {
  storeName: string
  storeDescription: string
  contactEmail: string
  contactPhone: string
  maintenanceMode: boolean
}

export type Product = {
  id: string
  name: string
  description: string
  price: number
  category: string
  stock: number
  sku: string
  status: "in-stock" | "low-stock" | "out-of-stock"
  createdAt: string
}

type AdminContextType = {
  settings: StoreSettings
  updateSettings: (newSettings: Partial<StoreSettings>) => void
  toggleMaintenanceMode: () => void
  isLoading: boolean
  stats: {
    totalProducts: number
    totalUsers: number
    totalOrders: number
    revenue: number
  }
  recentOrders: Array<{
    id: string
    customer: string
    amount: number
    status: string
    date: string
  }>
  products: Product[]
  addProduct: (product: Omit<Product, "id" | "createdAt">) => void
}

const defaultSettings: StoreSettings = {
  storeName: "My Awesome Store",
  storeDescription: "The best products at the best prices",
  contactEmail: "contact@store.com",
  contactPhone: "+1 (555) 123-4567",
  maintenanceMode: false,
}

// Sample products data
const sampleProducts: Product[] = [
  {
    id: "prod-1",
    name: "Premium Wireless Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    price: 199.99,
    category: "electronics",
    stock: 45,
    sku: "HDPH-001",
    status: "in-stock",
    createdAt: "2023-04-15",
  },
  {
    id: "prod-2",
    name: "Organic Cotton T-Shirt",
    description: "Comfortable 100% organic cotton t-shirt",
    price: 29.99,
    category: "clothing",
    stock: 120,
    sku: "SHRT-002",
    status: "in-stock",
    createdAt: "2023-04-10",
  },
  {
    id: "prod-3",
    name: "Smart Home Hub",
    description: "Control all your smart devices from one central hub",
    price: 149.99,
    category: "electronics",
    stock: 8,
    sku: "SMRT-003",
    status: "low-stock",
    createdAt: "2023-03-25",
  },
  {
    id: "prod-4",
    name: "Stainless Steel Water Bottle",
    description: "Eco-friendly reusable water bottle",
    price: 24.99,
    category: "home",
    stock: 0,
    sku: "BOTL-004",
    status: "out-of-stock",
    createdAt: "2023-03-20",
  },
  {
    id: "prod-5",
    name: "Fitness Tracker Watch",
    description: "Track your steps, heart rate, and sleep patterns",
    price: 89.99,
    category: "electronics",
    stock: 35,
    sku: "FTNS-005",
    status: "in-stock",
    createdAt: "2023-03-15",
  },
]

const AdminContext = createContext<AdminContextType | undefined>(undefined)

export function AdminProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<StoreSettings>(defaultSettings)
  const [isLoading, setIsLoading] = useState(true)
  const [products, setProducts] = useState<Product[]>(sampleProducts)
  const { toast } = useToast()

  const [stats] = useState({
    totalProducts: 150,
    totalUsers: 1250,
    totalOrders: 450,
    revenue: 45000,
  })

  const [recentOrders] = useState([
    {
      id: "ORD-001",
      customer: "John Doe",
      amount: 125.99,
      status: "Completed",
      date: "2023-05-15",
    },
    {
      id: "ORD-002",
      customer: "Jane Smith",
      amount: 89.5,
      status: "Processing",
      date: "2023-05-14",
    },
    {
      id: "ORD-003",
      customer: "Robert Johnson",
      amount: 210.75,
      status: "Completed",
      date: "2023-05-13",
    },
    {
      id: "ORD-004",
      customer: "Emily Davis",
      amount: 45.25,
      status: "Shipped",
      date: "2023-05-12",
    },
    {
      id: "ORD-005",
      customer: "Michael Wilson",
      amount: 175.0,
      status: "Processing",
      date: "2023-05-11",
    },
  ])

  useEffect(() => {
    // Load settings from localStorage if available
    const storedSettings = localStorage.getItem("storeSettings")
    if (storedSettings) {
      setSettings(JSON.parse(storedSettings))
    }

    // Load products from localStorage if available
    const storedProducts = localStorage.getItem("storeProducts")
    if (storedProducts) {
      setProducts(JSON.parse(storedProducts))
    }

    setIsLoading(false)
  }, [])

  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    const updatedSettings = { ...settings, ...newSettings }
    setSettings(updatedSettings)
    localStorage.setItem("storeSettings", JSON.stringify(updatedSettings))

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Settings updated",
        description: "Your store settings have been updated successfully.",
      })
    }, 500)
  }

  const toggleMaintenanceMode = () => {
    const updatedSettings = {
      ...settings,
      maintenanceMode: !settings.maintenanceMode,
    }
    setSettings(updatedSettings)
    localStorage.setItem("storeSettings", JSON.stringify(updatedSettings))

    // Simulate API call
    setTimeout(() => {
      toast({
        title: `Maintenance mode ${updatedSettings.maintenanceMode ? "enabled" : "disabled"}`,
        description: `Your store is now ${updatedSettings.maintenanceMode ? "in maintenance mode" : "live"}.`,
      })
    }, 500)
  }

  const addProduct = (product: Omit<Product, "id" | "createdAt">) => {
    // Generate a unique ID and current date
    const newProduct: Product = {
      ...product,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString().split("T")[0],
      status: product.stock > 10 ? "in-stock" : product.stock > 0 ? "low-stock" : "out-of-stock",
    }

    const updatedProducts = [...products, newProduct]
    setProducts(updatedProducts)

    // Save to localStorage
    localStorage.setItem("storeProducts", JSON.stringify(updatedProducts))
  }

  return (
    <AdminContext.Provider
      value={{
        settings,
        updateSettings,
        toggleMaintenanceMode,
        isLoading,
        stats,
        recentOrders,
        products,
        addProduct,
      }}
    >
      {children}
    </AdminContext.Provider>
  )
}

export function useAdmin() {
  const context = useContext(AdminContext)
  if (context === undefined) {
    throw new Error("useAdmin must be used within an AdminProvider")
  }
  return context
}
